# CIoT_Course
Public API package for virtual stock market trading platform. For 'Fundamentals of Deep Learning Networks: Theory and Industrial Applications' course of National Cheng Kung University, 2023.

# Usage

from CIoT_Course import api